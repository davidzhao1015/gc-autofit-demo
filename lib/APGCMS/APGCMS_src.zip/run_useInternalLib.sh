Rscript apgcms_main.R --infiledir='G-S-Dec613' --lib.internal='SERUM' --internalstd='Ribitol' --plotonly=FALSE
